from flask import Flask, session,render_template,request
import pymysql       
import json
from register import register_yourself
from mark_attendance import mark_your_attendance 
from datetime import timedelta,datetime
from geopy.distance import geodesic
import geocoder
import ast
import cv2
from tensorflow.keras.models import load_model
import numpy as np
from collections import deque
import zipfile
import pyzipper
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email import encoders
import os

app = Flask(__name__)

UPLOAD_AUDIO_FOLDER = 'static/audiofiles/'
app.config['UPLOAD_AUDIO_FOLDER'] = UPLOAD_AUDIO_FOLDER

def dbConnection():
    try:
        connection = pymysql.connect(host="localhost", user="root", password="root", database="atmfraud")
        return connection
    except:
        print("Something went wrong in database Connection")

def dbClose():
    try:
        dbConnection().close()
    except:
        print("Something went wrong in Close DB Connection")

app.secret_key = 'any random string'

con = dbConnection()
cursor = con.cursor()

loaded_model = load_model("MoBiLSTM_ATM_model.h5")
IMAGE_HEIGHT , IMAGE_WIDTH = 64, 64
SEQUENCE_LENGTH = 16
CLASSES_LIST = ["NonAnamoly","Anamoly"]
    
@app.route("/",methods=['POST','GET'])
def index():    
    return render_template('index.html')

@app.route("/register",methods=['POST','GET'])
def register():    
    return render_template('register.html')

@app.route("/about",methods=['POST','GET'])
def about():    
    return render_template('about.html')

@app.route("/atmService",methods=['POST','GET'])
def atmService():    
    return render_template('AtmService.html')

@app.route("/features",methods=['POST','GET'])
def feature():    
    return render_template('features.html')

@app.route("/main",methods=['POST','GET'])
def main():    
    return render_template('index.html')

@app.route('/logout')
def logout():
    session.pop('name',None)
    return render_template('login.html') 
    
def zip_with_password(input_file, output_zip, password):
    with pyzipper.AESZipFile(output_zip, 'w', compression=zipfile.ZIP_DEFLATED, encryption=pyzipper.WZ_AES) as zf:
        zf.setpassword(password)
        zf.write(input_file)

def sendvideofilemailtouser(usermail,output_zip_file):
    sender_email = "atm.serviceproviders20@gmail.com"
    receiver_email = usermail
    password = "svwrekoggyfclmar"
    
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = receiver_email
    message["Subject"] = "Password-protected Video Attachment"
    
    body = "Dear user,\n\nWe hope this message reaches you promptly.\n\nWe regret to inform you of a concerning incident that has been detected at one of our ATM locations. Our sophisticated security system has flagged unusual activity, indicating a potential theft occurrence. As part of our commitment to transparency and security, we are reaching out to inform you of this situation.\n\nTo provide you with further insight and aid in our investigation, we have encrypted the live footage captured from the ATM location. This encrypted footage has been securely sent to both yourself and our bank officials for review.\n\nTo decrypt the video footage and assist us in identifying any potential perpetrators, we kindly request your cooperation. Please utilize your Card number to decrypt the video footage provided.\n\nThank you for your cooperation and understanding in this matter. We sincerely appreciate your partnership in maintaining the security of our ATM network and ensuring the safety of all our valued customers.\n\nBest regards,\nSecureATM Team"
    message.attach(MIMEText(body, "plain"))
    
    filename = output_zip_file
    attachment_path = output_zip_file
    # Create a MIMEBase object
    with open(attachment_path, "rb") as attachment:
        part = MIMEBase("application", "octet-stream")
        part.set_payload(attachment.read())
    
    encoders.encode_base64(part)
    part.add_header(
        "Content-Disposition",
        f"attachment; filename= {filename}",
    )
    
    message.attach(part)
    text = message.as_string()
    with smtplib.SMTP("smtp.gmail.com", 587) as server:
        server.starttls()
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, text)
    
    print("Email sent successfully!")
    
def sendtextmailtouser(usermail,ogpass):   
    fromaddr = "atm.serviceproviders20@gmail.com"
    toaddr = usermail
    msg = MIMEMultipart()    
    msg['From'] = fromaddr  
    msg['To'] = toaddr
    msg['Subject'] = "ATM fraud"
    body = ogpass
    msg.attach(MIMEText(body, 'plain')) 
    s = smtplib.SMTP('smtp.gmail.com', 587) 
    s.starttls() 
    s.login(fromaddr, "svwrekoggyfclmar") 
    text = msg.as_string() 
    s.sendmail(fromaddr, toaddr, text) 
    s.quit() 

@app.route("/checkRegister",methods=['POST','GET'])
def checkRegister():   
    if request.method == "POST": 
        details = request.form
        
        fullname = details['fullname']
        email = details['email']
        mobile = details['mobile']
        cardnumber = details['cardnumber']
        cardpin = details['cardpin']
        age = details['age']
        
        cursor.execute('SELECT * FROM register WHERE cardnumber = %s or fullname = %s', (cardnumber,fullname))
        count = cursor.rowcount
        print(count)
        if count > 0: 
            return "fail"      
        else:
            status = register_yourself(fullname)
            if status == 'Success':                
                sql1 = "INSERT INTO register(fullname,email,mobile,cardnumber,cardpin,age)VALUES(%s,%s,%s,%s,%s,%s);"
                val1 = (fullname,email,mobile,cardnumber,cardpin,age)
                cursor.execute(sql1,val1)
                con.commit()
                return "success"   
            else:
                return "fail" 
                
def time_difference_greater_than_3_minutes(timestamp1, timestamp2, age):
    # Convert timestamps to datetime objects
    dt1 = datetime.strptime(timestamp1, "%Y-%m-%d %H:%M:%S")
    dt2 = datetime.strptime(timestamp2, "%Y-%m-%d %H:%M:%S")

    # Calculate the difference between timestamps
    time_diff = abs(dt1 - dt2)
    
    accToAge = 0
    if int(age) <= 30:
        accToAge+=40
    elif 30 < int(age) and int(age) < 50:
        accToAge+=70
    elif 50 <= int(age):
        accToAge+=120
    else:
        accToAge+=1
    
    print(accToAge)
    # Check if the time difference is greater than 3 minutes
    if time_diff > timedelta(seconds=accToAge):
        return True
    else:
        return False
 
def calculate_distance(location1, location2): 
    tuple_obj = ast.literal_eval(location2)
    return geodesic(location1, tuple_obj).kilometers

def calculate_oddtime(time_str):
    given_time = datetime.strptime(time_str, '%H:%M').time()
    current_time = datetime.now().time()
    given_datetime = datetime.combine(datetime.today(), given_time)
    current_datetime = datetime.combine(datetime.today(), current_time)
    time_difference = current_datetime - given_datetime
    difference_in_hours = time_difference.total_seconds() / 3600    
    return difference_in_hours

def is_Odd_Locandtime(cardholder_location,session_start_time,cardno):
    cursor.execute('SELECT * FROM transaction WHERE status = %s and cardnumber = %s', ("Pass",cardno))
    datacount = cursor.rowcount
    if datacount > 0:
        for i in cursor.fetchall():
            distance = calculate_distance(get_current_location(), i[8])
            time_difference = calculate_oddtime(i[4])
            print('--------------------------------------------')
            print(get_current_location())
            print(i[8])
            print(i[4])
            print('--------------------------------------------')
            print(time_difference)
            print(distance)
            # print(distance > 400)
            # print(-2.0 > time_difference)
            # print(2.0 < time_difference)
            if (distance > 10) or (-2.0 > time_difference) or (2.0 < time_difference):
                print("True")
                return True
    else:
        return False
    
def get_current_location():    
    g = geocoder.ip('me')
    latitude = g.latlng[0]
    longitude = g.latlng[1]
    return (latitude, longitude)

def identify_unusual_sequences(transactions, threshold_small, threshold_large):
    suspicious_sequences = []
    last_val = 0
    for transaction in transactions:
        amount = transaction['amount']
        if amount > last_val and amount > threshold_large:
            suspicious_sequences.append(transaction)
        last_val = amount
    return suspicious_sequences

def count_consecutive(data, target, n):
    count = 0
    for item in data:
        if item == target:
            count += 1
            if count >= n:
                return True
        else:
            count = 0
    return False

# Define a global variable or a flag to control the loop
stop_video_processing = False

# Function to stop the video processing loop
def stop_video_processing_loop():
    global stop_video_processing
    stop_video_processing = True
    
@app.route('/startAnamolyDetection',methods=['POST','GET'])
def startAnamolyDetection():    
    if request.method == "POST":
        details = request.form
        name = details['name']
        print(name)
        
        global stop_video_processing
        stop_video_processing = False
        
        returntext = 'Non-Anamoly'
        video_reader = cv2.VideoCapture("test_videos/1.mp4")
        # video_reader = cv2.VideoCapture(0)

        # Define the dimensions of the video
        width = int(video_reader.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(video_reader.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = 30
        
        # Create a VideoWriter object
        fourcc = cv2.VideoWriter_fourcc(*'XVID')
        out = cv2.VideoWriter('output_video.avi', fourcc, fps, (width, height)) 
        
        frames_queue = deque(maxlen = SEQUENCE_LENGTH)
        predicted_class_name = ''
        deciderlist=[]    
        
        while video_reader.isOpened() and not stop_video_processing:
        # while (True):
            ok, frame = video_reader.read()             
            if not ok:
                break
        
            resized_frame = cv2.resize(frame, (IMAGE_HEIGHT, IMAGE_WIDTH))
            normalized_frame = resized_frame / 255
            frames_queue.append(normalized_frame)
            if len(frames_queue) == SEQUENCE_LENGTH:                        
                predicted_labels_probabilities = loaded_model.predict(np.expand_dims(frames_queue, axis = 0))[0]
                predicted_label = np.argmax(predicted_labels_probabilities)
                predicted_class_name = CLASSES_LIST[predicted_label]
        
                deciderlist.append(predicted_class_name)
            if predicted_class_name == "Anamoly":
                cv2.putText(frame, predicted_class_name, (5, 100), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 3)
            else:
                cv2.putText(frame, predicted_class_name, (5, 100), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 255, 0), 3)
                
            cv2.imshow('frame', frame) 
            out.write(frame)       
            
            if count_consecutive(deciderlist, 'Anamoly', 20):
                returntext = 'Anamoly'
                break            
        
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
            
        video_reader.release()
        out.release()
        cv2.destroyAllWindows()
        
        if returntext == 'Anamoly':   
            input_video_file = 'output_video.avi'
            output_zip_file = 'video.zip'   
            passwordforlock = session.get("CardNo")
            
            zip_with_password(input_video_file, output_zip_file, passwordforlock.encode())
            
            CardHolderEmail = session.get("CardHolderEmail")
            sendvideofilemailtouser(CardHolderEmail,output_zip_file)
            
            os.remove('output_video.avi')
            os.remove('video.zip')
        return returntext
        

@app.route('/validateCard',methods=['POST','GET'])
def validateCard():
    if request.method == "POST":
        details = request.form
        cardnumber = details['cardnumber']
        print(cardnumber)    
        
        session_start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        session['session_start_time'] = session_start_time
        
        cursor.execute('SELECT * FROM register WHERE cardnumber = %s', (cardnumber))
        count = cursor.rowcount
        cardData= cursor.fetchone()  
        if count > 0:
            cardholder_location = get_current_location()
            if is_Odd_Locandtime(cardholder_location,session_start_time,cardnumber):
                CardHolderEmail = cardData[2] 
                CardHolderfullname = cardData[1]                  
                link = 'http://localhost:5000/authonticateTransaction1?name='+str(CardHolderfullname)+'&cardno='+str(cardnumber)
                sendtextmailtouser(CardHolderEmail,"Dear User,\n\nWe hope this message finds you well.\n\nWe are reaching out to you because our system has detected potentially fraudulent activity on your ATM card. We take the security of your accounts very seriously and want to ensure that your finances are protected at all times.\n\nThe transaction in question occurred at an unusual location and time, raising concerns about its legitimacy. To safeguard your funds and prevent any unauthorized access to your account, we kindly request your immediate attention.To authenticate this transaction and verify its legitimacy, please click on the attached link below. This will direct you to a secure portal where you can confirm whether you recognize and authorize the transaction in question.\n\n"+link+"\n\n If you identify any unauthorized transactions or if you have any concerns regarding the security of your account, please do not hesitate to contact our dedicated customer support team at 110 220 9800 for immediate assistance.\n\nWe are committed to safeguarding your financial well-being and will work diligently to ensure the security of your account.\n\nThank you for your attention to this matter.\n\nBest regards,\nSecureATM Team")  
                return "Oddlocation"
            else:        
                marked,finalname = mark_your_attendance()            
                if marked:                           
                    if str(finalname[0]) == str(cardData[1]):     
                        print(cardData)      
                        session['CardName'] = cardData[1]
                        session['CardNo'] = cardData[4]
                        session['CardHolderEmail'] = cardData[2]
                        session['CardHolderAge'] = cardData[6]
                        
                        jsonObject = json.dumps(cardData)
                        
                        return jsonObject
                    else: 
                        print("sendmail")
                        CardHolderEmail = cardData[2]
                        CardHolderfullname = cardData[1]                  
                        link = 'http://localhost:5000/authonticateTransaction1?name='+str(CardHolderfullname)+'&cardno='+str(cardnumber)
                        sendtextmailtouser(CardHolderEmail,"Dear User,\n\nWe hope this message finds you well.\n\nWe are reaching out to you because our system has detected potentially fraudulent activity on your ATM card. We take the security of your accounts very seriously and want to ensure that your finances are protected at all times.\n\nThe transaction in question occurred at an unusual location and time, raising concerns about its legitimacy. To safeguard your funds and prevent any unauthorized access to your account, we kindly request your immediate attention.To authenticate this transaction and verify its legitimacy, please click on the attached link below. This will direct you to a secure portal where you can confirm whether you recognize and authorize the transaction in question.\n\n"+link+"\n\n If you identify any unauthorized transactions or if you have any concerns regarding the security of your account, please do not hesitate to contact our dedicated customer support team at 110 220 9800 for immediate assistance.\n\nWe are committed to safeguarding your financial well-being and will work diligently to ensure the security of your account.\n\nThank you for your attention to this matter.\n\nBest regards,\nSecureATM Team")  
                        sql1 = "INSERT INTO transaction(fullname,cardnumber,transactiondate,transactiontime,amount,status,reason,location)VALUES(%s,%s,%s,%s,%s,%s,%s,%s);"
                        val1 = (cardData[1],cardData[4],datetime.now().strftime("%Y-%m-%d"),datetime.now().strftime("%H:%M"),'-',"Fail","Invalid Person",str(get_current_location()))
                        cursor.execute(sql1,val1)
                        con.commit()
                        
                        cursor.execute('SELECT * FROM transaction WHERE status = %s and transactiondate = %s and cardnumber = %s', ("Fail",datetime.now().strftime("%Y-%m-%d"),cardnumber))
                        failcount = cursor.rowcount
                        print("failcount")
                        print(failcount)
                        if failcount > 3:
                            print("sendmail")                            
                            CardHolderEmail = cardData[2]
                            sendtextmailtouser(CardHolderEmail,"Dear User,\n\nWe hope this message finds you well.\n\nWe are writing to inform you that our system has flagged a potentially fraudulent activity associated with your account. Specifically, we have detected multiple failed attempts to enter the correct PIN associated with your ATM card.\n\nFor your security and protection, we have taken immediate action to reject the transaction in question. Our decision to do so is in line with our commitment to safeguarding your financial assets and ensuring the integrity of your account.\n\n In the meantime, if you believe that your card may have been compromised or if you suspect any fraudulent activity, please do not hesitate to contact our customer support team immediately at 110 220 9800 for immediate assistance.\n\nWe are committed to safeguarding your financial well-being and will work diligently to ensure the security of your account.\n\nThank you for your attention to this matter.\n\nBest regards,\nSecureATM Team")
                        return "Invalidperson"
                else: 
                    print("sendmail")
                    CardHolderEmail = cardData[2]
                    CardHolderfullname = cardData[1]                  
                    link = 'http://localhost:5000/authonticateTransaction1?name='+str(CardHolderfullname)+'&cardno='+str(cardnumber)
                    sendtextmailtouser(CardHolderEmail,"Dear User,\n\nWe hope this message finds you well.\n\nWe are reaching out to you because our system has detected potentially fraudulent activity on your ATM card. We take the security of your accounts very seriously and want to ensure that your finances are protected at all times.\n\nThe transaction in question occurred at an unusual location and time, raising concerns about its legitimacy. To safeguard your funds and prevent any unauthorized access to your account, we kindly request your immediate attention.To authenticate this transaction and verify its legitimacy, please click on the attached link below. This will direct you to a secure portal where you can confirm whether you recognize and authorize the transaction in question.\n\n"+link+"\n\n If you identify any unauthorized transactions or if you have any concerns regarding the security of your account, please do not hesitate to contact our dedicated customer support team at 110 220 9800 for immediate assistance.\n\nWe are committed to safeguarding your financial well-being and will work diligently to ensure the security of your account.\n\nThank you for your attention to this matter.\n\nBest regards,\nSecureATM Team")  
                    sql1 = "INSERT INTO transaction(fullname,cardnumber,transactiondate,transactiontime,amount,status,reason,location)VALUES(%s,%s,%s,%s,%s,%s,%s,%s);"
                    val1 = (cardData[1],cardData[4],datetime.now().strftime("%Y-%m-%d"),datetime.now().strftime("%H:%M"),'-',"Fail","Invalid Person",str(get_current_location()))
                    cursor.execute(sql1,val1)
                    con.commit()
                    
                    cursor.execute('SELECT * FROM transaction WHERE status = %s and transactiondate = %s and cardnumber = %s', ("Fail",datetime.now().strftime("%Y-%m-%d"),cardnumber))
                    failcount = cursor.rowcount
                    print("failcount")
                    print(failcount)
                    if failcount > 3:
                        print("sendmail")                            
                        CardHolderEmail = cardData[2]
                        sendtextmailtouser(CardHolderEmail,"Dear User,\n\nWe hope this message finds you well.\n\nWe are writing to inform you that our system has flagged a potentially fraudulent activity associated with your account. Specifically, we have detected multiple failed attempts to enter the correct PIN associated with your ATM card.\n\nFor your security and protection, we have taken immediate action to reject the transaction in question. Our decision to do so is in line with our commitment to safeguarding your financial assets and ensuring the integrity of your account.\n\n In the meantime, if you believe that your card may have been compromised or if you suspect any fraudulent activity, please do not hesitate to contact our customer support team immediately at 110 220 9800 for immediate assistance.\n\nWe are committed to safeguarding your financial well-being and will work diligently to ensure the security of your account.\n\nThank you for your attention to this matter.\n\nBest regards,\nSecureATM Team")
                    return "Invalidperson"
        else:          
            return "cardnotfound"  
        
@app.route('/validatePin',methods=['POST','GET'])
def validatePin():
    if request.method == "POST":
        details = request.form
        cardpin = details['cardpin']
        print(cardpin)
        
        fullname = session.get("CardName")
        cardnumber = session.get("CardNo")
        
        cursor.execute('SELECT * FROM register WHERE fullname = %s and cardnumber = %s', (fullname,cardnumber))
        count = cursor.rowcount
        if count > 0:
            now = datetime.now()
            
            starttime = session.get("session_start_time")            
            endtime = now.strftime("%Y-%m-%d %H:%M:%S")
            
            if time_difference_greater_than_3_minutes(starttime, endtime, session.get("CardHolderAge")):
                stop_video_processing_loop()
                return "expired"
            else:
                row = cursor.fetchone()             
                if cardpin == str(row[5]):                 
                    return "success"
                else: 
                    stop_video_processing_loop()                                                       
                    sql1 = "INSERT INTO transaction(fullname,cardnumber,transactiondate,transactiontime,amount,status,reason,location)VALUES(%s,%s,%s,%s,%s,%s,%s,%s);"
                    val1 = (fullname,cardnumber,datetime.now().strftime("%Y-%m-%d"),datetime.now().strftime("%H:%M"),'-',"Fail","Invalid Pin",str(get_current_location()))
                    cursor.execute(sql1,val1)
                    con.commit()
                    
                    cursor.execute('SELECT * FROM transaction WHERE status = %s and transactiondate = %s and cardnumber = %s', ("Fail",datetime.now().strftime("%Y-%m-%d"),cardnumber))
                    failcount = cursor.rowcount
                    print("failcount")
                    print(failcount)
                    if failcount > 3:
                        print("sendmail")                            
                        CardHolderEmail = session.get("CardHolderEmail")
                        sendtextmailtouser(CardHolderEmail,"Dear user, Many failed tranaction")
                    return "fail"
        else:
            return "fail" 
        
@app.route('/validateAmount',methods=['POST','GET'])
def validateAmount():
    if request.method == "POST":
        details = request.form
        amount = details['amount']
        print(amount)        
        
        fullname = session.get("CardName")
        cardnumber = session.get("CardNo")
        
        if 40000 > int(amount):

            now = datetime.now()
            curdate = now.strftime("%Y-%m-%d")
            curtime = now.strftime("%H:%M")
            
            starttime = session.get("session_start_time")            
            endtime = now.strftime("%Y-%m-%d %H:%M:%S")
            
            print(starttime)
            print(endtime)
            
            if time_difference_greater_than_3_minutes(starttime, endtime, session.get("CardHolderAge")):                
                stop_video_processing_loop()
                return "Session expired"
            else: 
                threshold_small = 50  # Adjust as needed
                threshold_large = 25000  # Adjust as needed
                cursor.execute('SELECT * FROM transaction WHERE status = %s and cardnumber = %s', ("Pass",cardnumber))
                rowdata = cursor.fetchall()                
                transactions = [{'amount': int(data[5])} for data in rowdata]
                transactions.append({'amount': int(amount)})
                suspicious_sequences = identify_unusual_sequences(transactions, threshold_small, threshold_large)
                
                print(suspicious_sequences)
                if suspicious_sequences:                    
                    print("sendmail")                            
                    CardHolderEmail = session.get("CardHolderEmail")                    
                    link = 'http://localhost:5000/authonticateTransaction?name='+str(fullname)+'&cardno='+str(cardnumber)+'&amount='+str(amount)
                    sendtextmailtouser(CardHolderEmail,"Dear "+str(fullname)+",\n\nWe hope this message finds you well.\n\nWe regret to inform you that our fraud detection system has flagged a series of suspicious transactions associated with your ATM card. These transactions have raised concerns due the sudden occurrence of unusually large transactions beyond our approved threshold limit.To assist us in verifying the legitimacy of these transactions and restoring access to your card, we kindly request your cooperation. Please click on the attached link below to proceed with the authentication process. This will direct you to a secure portal where you can review the flagged transactions and confirm whether they were authorized by you.\n\n"+link+"\n\n If you identify any unauthorized transactions or if you have any concerns regarding the security of your account, please do not hesitate to contact our dedicated customer support team at 110 220 9800 for immediate assistance.\n\nWe are committed to safeguarding your financial well-being and will work diligently to ensure the security of your account.\n\nThank you for your attention to this matter.\n\nBest regards,\nSecureATM Team")
                    print("Suspicious sequences found:")
                    for sequence in suspicious_sequences:
                        print(sequence)
                        
                    stop_video_processing_loop()
                    sql1 = "INSERT INTO transaction(fullname,cardnumber,transactiondate,transactiontime,amount,status,reason,location)VALUES(%s,%s,%s,%s,%s,%s,%s,%s);"
                    val1 = (fullname,cardnumber,datetime.now().strftime("%Y-%m-%d"),datetime.now().strftime("%H:%M"),str(amount),"Fail","Suspicious sequences",str(get_current_location()))
                    cursor.execute(sql1,val1)
                    con.commit()
                    
                    cursor.execute('SELECT * FROM transaction WHERE status = %s and transactiondate = %s and cardnumber = %s', ("Fail",datetime.now().strftime("%Y-%m-%d"),cardnumber))
                    failcount = cursor.rowcount
                    print("failcount")
                    print(failcount)
                    if failcount > 3:
                        print("sendmail")                            
                        CardHolderEmail = session.get("CardHolderEmail")
                        sendtextmailtouser(CardHolderEmail,"Dear user, Many failed tranaction")
                    return "Suspicious sequences found"
                else:
                    cursor.execute('SELECT SUM(amount) FROM transaction WHERE fullname = %s AND cardnumber = %s AND transactiondate = %s AND status = %s', (fullname, cardnumber, curdate, "Pass")) 
                    data = cursor.fetchone()
                    if data[0] != None:
                        if data[0] > 40000:   
                            stop_video_processing_loop()                                                                            
                            sql1 = "INSERT INTO transaction(fullname,cardnumber,transactiondate,transactiontime,amount,status,reason,location)VALUES(%s,%s,%s,%s,%s,%s,%s,%s);"
                            val1 = (fullname,cardnumber,datetime.now().strftime("%Y-%m-%d"),datetime.now().strftime("%H:%M"),str(amount),"Fail","Limit Over",str(get_current_location()))
                            cursor.execute(sql1,val1)
                            con.commit()
                            
                            cursor.execute('SELECT * FROM transaction WHERE status = %s and transactiondate = %s and cardnumber = %s', ("Fail",datetime.now().strftime("%Y-%m-%d"),cardnumber))
                            failcount = cursor.rowcount  
                            print("failcount")
                            print(failcount)
                            if failcount > 3:
                                print("sendmail")                            
                                CardHolderEmail = session.get("CardHolderEmail")
                                sendtextmailtouser(CardHolderEmail,"Dear "+str(fullname)+",\n\nWe hope this message finds you well.\n\nWe regret to inform you that our fraud detection system has rejected the recent transaction attempt as your daily transaction limit has been exceeded with your ATM card. These transactions have raised concerns due to occurrence of unusually large withdrawal at a particular day.\n\nFor your security and protection, we have taken immediate action to reject the transaction in question. Our decision to do so is in line with our commitment to safeguarding your financial assets and ensuring the integrity of your account.\n\nIn the meantime, if you believe that your card may have been compromised or if you suspect any fraudulent activity, please do not hesitate to contact our customer support team immediately at 110 220 9800.\n\nWe are committed to safeguarding your financial well-being and will work diligently to ensure the security of your account.\n\nThank you for your attention to this matter.\n\nBest regards,\nSecureATM Team")
                            return "Your Transaction limit is over!"
                        else:    
                            stop_video_processing_loop()
                            sql1 = "INSERT INTO transaction(fullname,cardnumber,transactiondate,transactiontime,amount,status,reason,location)VALUES(%s,%s,%s,%s,%s,%s,%s,%s);"
                            val1 = (fullname,cardnumber,curdate,curtime,amount,"Pass","Done",str(get_current_location()))
                            cursor.execute(sql1,val1)
                            con.commit()
                            return "success"                
                    else: 
                        stop_video_processing_loop()                       
                        sql1 = "INSERT INTO transaction(fullname,cardnumber,transactiondate,transactiontime,amount,status,reason,location)VALUES(%s,%s,%s,%s,%s,%s,%s,%s);"
                        val1 = (fullname,cardnumber,curdate,curtime,amount,"Pass","Done",str(get_current_location()))
                        cursor.execute(sql1,val1)
                        con.commit()
                        return "success"
        else:  
            stop_video_processing_loop()
            print("sendmail")                               
            CardHolderEmail = session.get("CardHolderEmail")
            link = 'http://localhost:5000/authonticateTransaction?name='+str(fullname)+'&cardno='+str(cardnumber)+'&amount='+str(amount)
            messagetobesent = "Dear "+str(fullname)+",\n\nWe hope this message finds you well.\n\nWe regret to inform you that our fraud detection system has flagged a series of suspicious transactions associated with your ATM card. These transactions have raised concerns due to occurrence of unusually large transactions multiple times.\n\nTo assist us in verifying the legitimacy of these transactions and restoring access to your card, we kindly request your cooperation. Please click on the attached link below to proceed with the authentication process. This will direct you to a secure portal where you can review the flagged transactions and confirm whether they were authorized by you.\n\n"+link+"\n\n If you identify any unauthorized transactions or if you have any concerns regarding the security of your account, please do not hesitate to contact our dedicated customer support team at 110 220 9800 for immediate assistance.\n\nWe are committed to safeguarding your financial well-being and will work diligently to ensure the security of your account.\n\nThank you for your attention to this matter.\n\nBest regards,\nSecureATM Team"
            sendtextmailtouser(CardHolderEmail,messagetobesent)                                                   
            sql1 = "INSERT INTO transaction(fullname,cardnumber,transactiondate,transactiontime,amount,status,reason,location)VALUES(%s,%s,%s,%s,%s,%s,%s,%s);"
            val1 = (fullname,cardnumber,datetime.now().strftime("%Y-%m-%d"),datetime.now().strftime("%H:%M"),str(amount),"Fail","Amount Exceeded",str(get_current_location()))
            cursor.execute(sql1,val1)
            con.commit()
            
            cursor.execute('SELECT * FROM transaction WHERE status = %s and transactiondate = %s and cardnumber = %s', ("Fail",datetime.now().strftime("%Y-%m-%d"),cardnumber))
            failcount = cursor.rowcount
            print("failcount")
            print(failcount)
            if failcount > 3:
                print("sendmail")                            
                CardHolderEmail = session.get("CardHolderEmail")
                sendtextmailtouser(CardHolderEmail,"Dear user, Many failed tranaction")
            return "The amount is exceeded!"
        
@app.route("/authonticateTransaction", methods=['GET'])
def authonticateTransaction():
    # Retrieve parameters from the query string
    name = request.args.get('name')
    cardno = request.args.get('cardno')
    amount = request.args.get('amount')

    # Process the data
    print("Name:", name)
    print("Card Number:", cardno)
    print("Amount:", amount)
    return render_template('authonticateTransaction.html',name=name,cardno=cardno,amount=amount)

@app.route("/authonticateTransaction1", methods=['GET'])
def authonticateTransaction1():
    name = request.args.get('name')
    cardno = request.args.get('cardno')

    # Process the data
    print("Name:", name)
    print("Card Number:", cardno)
    return render_template('authonticateTransaction1.html',name=name,cardno=cardno)

@app.route('/auth',methods=['POST','GET'])
def auth():
    if request.method == "POST":
        details = request.form
        fullname = details['fullname']
        card = details['card']
        amount = details['amount']
        typeof = details['type']
        
        if typeof == 'No':               
            sql1 = "INSERT INTO transaction(fullname,cardnumber,transactiondate,transactiontime,amount,status,reason,location)VALUES(%s,%s,%s,%s,%s,%s,%s,%s);"
            val1 = (fullname,card,datetime.now().strftime("%Y-%m-%d"),datetime.now().strftime("%H:%M"),amount,"Fail","Auth fail",str(get_current_location()))
            cursor.execute(sql1,val1)
            con.commit()
            
            return "Transaction Failed"
        else:               
            sql1 = "INSERT INTO transaction(fullname,cardnumber,transactiondate,transactiontime,amount,status,reason,location)VALUES(%s,%s,%s,%s,%s,%s,%s,%s);"
            val1 = (fullname,card,datetime.now().strftime("%Y-%m-%d"),datetime.now().strftime("%H:%M"),amount,"Pass","Auth sucess",str(get_current_location()))
            cursor.execute(sql1,val1)
            con.commit()
            
            return "Success"
            

if __name__ == '__main__':
    app.run('0.0.0.0')
    # app.run(debug=True)