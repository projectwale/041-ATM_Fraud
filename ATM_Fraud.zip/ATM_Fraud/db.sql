/*
SQLyog Community Edition- MySQL GUI v7.01 
MySQL - 5.0.27-community-nt : Database - atmfraud
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`atmfraud` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `atmfraud`;

/*Table structure for table `register` */

DROP TABLE IF EXISTS `register`;

CREATE TABLE `register` (
  `id` int(255) NOT NULL auto_increment,
  `fullname` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `mobile` varchar(255) default NULL,
  `cardnumber` varchar(255) default NULL,
  `cardpin` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `register` */

insert  into `register`(`id`,`fullname`,`email`,`mobile`,`cardnumber`,`cardpin`) values (1,'Yash Salvi','yashsalvi1299@gmail.com','3456895623','345678956458','34');

/*Table structure for table `transaction` */

DROP TABLE IF EXISTS `transaction`;

CREATE TABLE `transaction` (
  `id` int(255) NOT NULL auto_increment,
  `fullname` varchar(255) default NULL,
  `cardnumber` varchar(255) default NULL,
  `transactiondate` varchar(255) default NULL,
  `transactiontime` varchar(255) default NULL,
  `amount` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `transaction` */

insert  into `transaction`(`id`,`fullname`,`cardnumber`,`transactiondate`,`transactiontime`,`amount`) values (1,'Yash Salvi','345678956458','2024-02-01','15:04','3489'),(2,'Yash Salvi','345678956458','2024-02-01','15:04','345'),(3,'Yash Salvi','345678956458','2024-02-01','15:05','4455');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
