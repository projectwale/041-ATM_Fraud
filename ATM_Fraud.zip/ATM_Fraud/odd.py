def identify_unusual_sequences(transactions, threshold_small, threshold_large):
    suspicious_sequences = []
    last_val = 0
    for transaction in transactions:
        amount = transaction['amount']
        print()
        print(amount,threshold_small,last_val,threshold_large)
        print(amount > threshold_small,last_val > threshold_large)
        print()
        if amount > last_val and amount > threshold_large:
            suspicious_sequences.append(transaction)
        last_val = amount
    return suspicious_sequences

# Example transactions (replace this with your actual data)
transactions = [
    {'amount': 10},
    {'amount': 20},
    {'amount': 500},
    {'amount': 1000},
    {'amount': 10000},
    {'amount': 8},
    {'amount': 10},
]

# Define thresholds for small and large transactions
threshold_small = 100  # Adjust as needed
threshold_large = 1000  # Adjust as needed

# Identify unusual sequences
suspicious_sequences = identify_unusual_sequences(transactions, threshold_small, threshold_large)

# Print suspicious sequences
if suspicious_sequences:
    print("Suspicious sequences found:")
    for sequence in suspicious_sequences:
        print(sequence)
else:
    print("No suspicious sequences found.")





















# from geopy.distance import geodesic
# from geopy.geocoders import Nominatim

# import geocoder

# # Function to calculate distance between two geographic coordinates
# def calculate_distance(location1, location2):
#     return geodesic(location1, location2).kilometers

# # Function to check if transaction location is significantly distant
# def is_distant_transaction(cardholder_location, transaction_location, threshold_distance):
#     distance = calculate_distance(cardholder_location, transaction_location)
#     print(distance)
#     return distance > threshold_distance
    
# def get_current_location():    
#     g = geocoder.ip('me')
#     latitude = g.latlng[0]
#     longitude = g.latlng[1]
#     return (latitude, longitude)

# # Example usage
# cardholder_location = get_current_location()  # New York City coordinates (latitude, longitude)
# transaction_location = (19.0522, 72.2437)  # Los Angeles coordinates

# # Check if transaction location is significantly distant
# threshold_distance = 200  # Threshold distance in kilometers
# print(is_distant_transaction(cardholder_location, transaction_location, threshold_distance))
