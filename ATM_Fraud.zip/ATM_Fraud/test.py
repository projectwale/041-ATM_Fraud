from flask import Flask, session,render_template,request
import pymysql       
import json
from register import register_yourself
from mark_attendance import mark_your_attendance 
from datetime import timedelta,datetime
from geopy.distance import geodesic
import geocoder
import ast
import cv2
from tensorflow.keras.models import load_model
import numpy as np
from collections import deque
import zipfile
import pyzipper
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

loaded_model = load_model("MoBiLSTM_ATM_model.h5")
IMAGE_HEIGHT , IMAGE_WIDTH = 64, 64
SEQUENCE_LENGTH = 16
CLASSES_LIST = ["NonAnamoly","Anamoly"]

def zip_with_password(input_file, output_zip, password):
    with pyzipper.AESZipFile(output_zip, 'w', compression=zipfile.ZIP_DEFLATED, encryption=pyzipper.WZ_AES) as zf:
        zf.setpassword(password)
        zf.write(input_file)

def sendvideofilemailtouser(usermail,output_zip_file):
    sender_email = "pranalibscproject@gmail.com"
    receiver_email = usermail
    password = "wkwfgosewcljcpqh"
    
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = receiver_email
    message["Subject"] = "Password-protected Video Attachment"
    
    filename = output_zip_file
    attachment_path = output_zip_file
    # Create a MIMEBase object
    with open(attachment_path, "rb") as attachment:
        part = MIMEBase("application", "octet-stream")
        part.set_payload(attachment.read())
    
    encoders.encode_base64(part)
    part.add_header(
        "Content-Disposition",
        f"attachment; filename= {filename}",
    )
    
    message.attach(part)
    text = message.as_string()
    with smtplib.SMTP("smtp.gmail.com", 587) as server:
        server.starttls()
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, text)
    
    print("Email sent successfully!")
    
def count_consecutive(data, target, n):
    count = 0
    for item in data:
        if item == target:
            count += 1
            if count >= n:
                return True
        else:
            count = 0
    return False

returntext = 'Non-Anamoly'
video_reader = cv2.VideoCapture("test_videos/13.mp4")
 
# video_reader = cv2.VideoCapture(0)
frames_queue = deque(maxlen = SEQUENCE_LENGTH)
predicted_class_name = ''
deciderlist=[] 


# Define the dimensions of the video
width = int(video_reader.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(video_reader.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = 30

# Create a VideoWriter object
fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter('output_video.avi', fourcc, fps, (width, height))   
 
while video_reader.isOpened():
# while (True):
    ok, frame = video_reader.read()             
    if not ok:
        break

    resized_frame = cv2.resize(frame, (IMAGE_HEIGHT, IMAGE_WIDTH))
    normalized_frame = resized_frame / 255
    frames_queue.append(normalized_frame)
    if len(frames_queue) == SEQUENCE_LENGTH:                        
        predicted_labels_probabilities = loaded_model.predict(np.expand_dims(frames_queue, axis = 0))[0]
        predicted_label = np.argmax(predicted_labels_probabilities)
        predicted_class_name = CLASSES_LIST[predicted_label]

        deciderlist.append(predicted_class_name)
    if predicted_class_name == "Anamoly":
        cv2.putText(frame, predicted_class_name, (5, 100), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 3)
    else:
        cv2.putText(frame, predicted_class_name, (5, 100), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 255, 0), 3)
        
    cv2.imshow('frame', frame) 
    # Write the frame to the video file
    out.write(frame)         

    if count_consecutive(deciderlist, 'Anamoly', 200):
        returntext = 'Anamoly'
        break  
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
     
video_reader.release()
out.release()
cv2.destroyAllWindows()
 
print(returntext)
if returntext == 'Anamoly':   
    input_video_file = 'output_video.avi'
    output_zip_file = 'video.zip'   
    passwordforlock = '12345'
    
    zip_with_password(input_video_file, output_zip_file, passwordforlock.encode())
    
    CardHolderEmail = 'yashsalvi1999@gmail.com'
    sendvideofilemailtouser(CardHolderEmail,output_zip_file)